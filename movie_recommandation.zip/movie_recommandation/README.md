# 🎬 Movie Recommendation Notebook - Dockerized

Ce projet est un notebook Jupyter (`movieclass.ipynb`) qui explore des méthodes de recommandation de films en utilisant des techniques de clustering comme KMedoids et des distances de similarité (Jaccard, PCA, etc.).

Le projet est entièrement **conteneurisé avec Docker**, ce qui permet de l'exécuter facilement sans avoir à installer Python ou les bibliothèques à la main.

---

## 🧰 Technologies utilisées

- Python (pandas, numpy, matplotlib, scikit-learn, scikit-learn-extra, scipy)
- Jupyter Notebook
- Docker

---

## 🚀 Exécution avec Docker

### 1. ⚙️ Prérequis

- Installer [Docker Desktop](https://www.docker.com/products/docker-desktop/)

---

### 2. 📥 Cloner le dépôt GitHub

```bash
git clone https://github.com/ESSAMITMeryam/movie_recommandation.git
cd movie_recommandation

### 3. 🏁 Lancer le conteneur
Démarrez le notebook Jupyter à l’intérieur d’un conteneur Docker :
    docker run -p 8888:8888 movie-recommandation